---
title: "Startseite"
date: "2025-07-01"
author: "Digitalista e.V."
---
  
## Unsere Projekte
[![Digital Volunteers]({{github_dev_path}}/image_2023-02-13_203311065.png)](https://digitalvolunteers.de/)

**Digital Volunteers**


## Spenden

[UAhelp – digitale Informationsangebote für geflüchtete aus der Ukraine](https://www.betterplace.org/de/projects/118066?utm_campaign=user_share&utm_medium=ppp_sticky&utm_source=Link)


## Dokumente

Vereins Dokumente herunterladen:

- [Satzung]({{github_dev_path}}/Satzung-2022-08-23.pdf)
- [Beitragsordnung]({{github_dev_path}}/Beitragsordnung-Digitalista-e.V.-2023-02-13.pdf)
- Aufnahmeantrag

