import React from "react";
import Header from "./components/header";
import Footer from "./components/footer";
import styles from "./styles/layout.module.css";

export const metadata = {
  metadataBase: new URL("https://digitalista-ev.de"),
  title: "Digitalista e.V.",
  description: "Digitalista - Unsere Projekte und Dokumente",
  keywords: ["Digitalista", "Ehrenamt", "Digitalisierung", "Projekte", "Spenden", "Verein"],
  authors: [{ name: "Digitalista e.V." }],
  openGraph: {
    title: "Digitalista e.V.",
    description: "Digitalista - Unsere Projekte und Dokumente",
    type: "website",
    url: "https://digitalista-ev.de",
    images: [
      {
        url: "https://digitalista-ev.de/og-image.jpg",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Digitalista e.V.",
    description: "Digitalista - Unsere Projekte und Dokumente",
    images: ["https://digitalista-ev.de/og-image.jpg"],
  },
  icons: {
    icon: [
      { url: "/favicon.ico", type: "image/x-icon" },
    ],
  },
  alternates: {
    canonical: "https://digitalista-ev.de",
  },
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
};

export default function Layout({ children }) {
  return (
    <html lang="de">
      <body className={styles.body}>
        <Header />
        <main className={styles.main}>{children}</main>
        <Footer />
      </body>
    </html>
  );
}
