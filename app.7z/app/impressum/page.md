---
title: "Impressum"
date: "2025-07-01"
author: "Digitalista e.V."
---
<div style="background-color: #f0f0f0; padding: 1rem;">

# Impressum

**Digitalista e.V.**  
**Berlin**   
**Deutschland**  

**E-Mail: info@digitalista-ev.de**  

**Verantwortlicher gemäß §10 Abs.3 MDStV:**  
**Alexandra Kovalenko**  

## Inhalte und Haftungsausschluss
Die vorstehenden Informationen und Texte stellen keine Rechtsberatung oder Werbung von kommerziele Services dar. Für Richtigkeit und Aktualität kann daher keine Haftung übernommen werden.

Trotz sorgfältiger inhaltlicher Kontrolle übernehmen wir keine Haftung für die Inhalte externer Links. Für den Inhalt der verlinkten Seiten sind ausschließlich deren Betreiber verantwortlich.

## Weitergabe
Sämtliche angebotenen Informationen dürfen – auch auszugsweise – nur mit schriftlicher Genehmigung von Digitalista e.V. weiterverbreitet oder anderweitig veröffentlicht werden.

## Urheberrecht
Texte und Grafiken von Digitalista sowie Digital Volunteers sind durch das Urheberrecht geschützt. Das Verwenden der Texte und Grafiken von Digitalista e.V. sowie Digital Volunteers auf eigenen Web-Seiten oder in anderen Medien ohne ausdrückliche Genehmigung verletzt das Urheberrecht und wird bei Entdecken abgemahnt und falls notwendig auch gerichtlich verfolgt.

</div>